

# Validation Report for LDAP Functions for SOAR

| SDK Version       | Generation Time          | Command Line Arguments Provided |
| :---------------- | ------------------------ | ------------------------------- |
| 46.0.3461 | 2022/09/12 05:44:08 | `cmd`: validate, `package`: ., `validate`: True |

## App Details
| Attribute | Value |
| --------- | ----- |
| `display_name` | LDAP Functions for SOAR |
| `name` | fn_my_ldap |
| `version` | 1.0.0 |
| `author` | IBM SOAR |
| `install_requires` | ['resilient-circuits>=46.0.0', 'ldap3'] |
| `description` | App to Search, and enable/disable users in LDAP system |
| `long_description` | App provides functionality to search for users, enable users, and disable users in a LDAP system. |
| `url` | ibm.com |
| `entry_points` | {'resilient.circuits.configsection': '/home/resadmin/msu_demo/fn_my_ldap/fn_my_ldap/util/config.py',<br> 'resilient.circuits.customize': '/home/resadmin/msu_demo/fn_my_ldap/fn_my_ldap/util/customize.py',<br> 'resilient.circuits.selftest': '/home/resadmin/msu_demo/fn_my_ldap/fn_my_ldap/util/selftest.py'} |
| `python_requires` | >=3.6 |
| `SOAR version` | 46.0.8131 |
| `Proxy support` | Proxies supported if running on AppHost>=1.6 |

---


## `setup.py` file validation
| Severity | Name | Description | Solution |
| --- | --- | --- | --- |
| <span style="color:orange">WARNING</span> | invalid value in `setup.py` | `install_requires` has the following improperly formatted dependencies: [`ldap3`] | All dependencies (other than resilient-circuits) must be include a version in the format `~=` or `==` |


---


## Package files validation

### `README.md`
<span style="color:red">CRITICAL</span>: `README.md` is still the `codegen` template

Be sure that you run ```resilient-sdk docgen -p /home/resadmin/msu_demo/fn_my_ldap``` when you are done developing


### LICENSE
<span style="color:red">CRITICAL</span>: `LICENSE` is the default license file

Provide a `LICENSE` file in your package directory. Suggested formats: MIT, Apache, and BSD


### `app_logo.png`
<span style="color:teal">INFO</span>: `app_logo.png` is the default icon. Consider using your own logo

Icons appear in SOAR when your app is installed with App Host


### `company_logo.png`
<span style="color:teal">INFO</span>: `company_logo.png` is the default icon. Consider using your own logo

Icons appear in SOAR when your app is installed with App Host


### `MANIFEST.in`
<span style="color:green">Pass</span>


### `apikey_permissions.txt`
<span style="color:green">Pass</span>


### `Dockerfile, template match`
<span style="color:green">Pass</span>


### `Dockerfile, base image`
<span style="color:green">Pass</span>


### `entrypoint.sh`
<span style="color:green">Pass</span>


### ``config.py``
<span style="color:green">Pass</span>


### ``customize.py``
<span style="color:green">Pass</span>

 
---
 

## Payload samples validation

### `payload_samples/my_ldap_search`
<span style="color:red">CRITICAL</span>: `output_json_example.json` and `output_json_schema.json` for `my_ldap_search` empty

Fill in values manually or by using ```resilient-sdk codegen -p /home/resadmin/msu_demo/fn_my_ldap --gather-results```


### `payload_samples/my_ldap_toggle_access`
<span style="color:red">CRITICAL</span>: `output_json_example.json` and `output_json_schema.json` for `my_ldap_toggle_access` empty

Fill in values manually or by using ```resilient-sdk codegen -p /home/resadmin/msu_demo/fn_my_ldap --gather-results```

 
---
 

 

 

 

 